## Expected Behavior 


## Actual Behavior


## Steps to Reproduce the Problem

  1. 
  1. 
  1. 

## Specifications

Please add this info:

  1. Output of ```facter -p``` on the failing node (at least the OS related facts)
  1. Version of Puppet and of the module
  1. The relevant Puppet code and eventually Hiera data
